<?php

class model_hms extends CI_Model {

    function __construct()
    {
        parent::__construct();
        $this->load->database('hmsdb');
    }
    public function get_all_users()
    {
        $query = $this->db->get('admissiontbl');
        return $query->result();
    }
    public function get_regNo()
    {
        $query = $this->db->select('regNo')->order_by('regNo','desc')->limit(1)->get('admissiontbl');
        return $query->result_array();

    }
    public function insert_users_to_db($data)
    {
        return $this->db->insert('admissiontbl', $data);
    }
    public function insert_discharge_to_db($data)
    {
        return $this->db->insert('dischargetbl', $data);
    }

public  function delete_from_adm($id){
        return $this->db->delete('admissiontbl', array('regNo' => $id));
}
    public function ajax_search_by_cnic($qs){
                                                    //?_type=query&q=page
        $json = [];
        if(!empty($qs)){
            $query = $this->db->select("regNo AS id, patName AS name, patStatus")
                ->like('patCNIC', $qs)
                ->or_like('patName', $qs)
                ->or_like('regNo', $qs)
                ->where('patStatus !=', 'Discharged')
                              ->get('admissiontbl');
            $json = $query -> result_array();
        }
        //echo json_encode($json);
       // print_r($json);
        echo "[";
        $braces = '';
        foreach ($json as $result)
            {
                echo $braces . " {\n";
                echo '  "id": "' .$result['id']. '",' . "\n";
                echo '	"text": "' . $result['name'] .'"' . "\n";
                $braces = ",\n";
                echo "}\n";
            }
        echo "]";
    }
    public function search_result_by_cnic($qs)
    {
        if(!empty($qs)) {
            $query = $this->db->select('*')
                ->like('patCNIC', $qs)
                ->or_like('patName', $qs)
                ->or_like('regNo', $qs)
                ->where('patStatus !=', 'Discharged')
                ->get('admissiontbl');
            return $query->result_array();
        }
    }
    public function ajax_search_discharged_by_cnic($qs){
        //?_type=query&q=page
        $json = [];
        if(!empty($qs)){
            $query = $this->db->select("regNo AS id, patName AS name")
                ->where('regNo', $qs)
                ->where('patStatus', 'Discharged')

                ->get('admissiontbl');
            $json = $query -> result_array();
        }
        //echo json_encode($json);
        // print_r($json);
        echo "[";
        $braces = '';
        foreach ($json as $result)
        {
            echo $braces . " {\n";
            echo '  "id": "' .$result['id']. '",' . "\n";
            echo '	"text": "' . $result['name'] .'"' . "\n";
            $braces = ",\n";
            echo "}\n";
        }
        echo "]";
    }
    public function search_result_discharged_by_cnic($qs)
    {
        if(!empty($qs)) {
            $query = $this->db->select('*')
                ->where('regNo', $qs)
                ->where('patStatus', 'Discharged')
                ->get('admissiontbl');
            return $query->result_array();
        }
    }
    public function ajax_search_by_ward($qs){
        //?_type=query&q=page
        $json = [];
        if(!empty($qs) && $qs == "true"){
            $query = $this->db->select("wardId AS id")
                ->get('wardtbl');
            $json = $query -> result_array();
        }

        echo "[";
        $braces = '';
        foreach ($json as $result)
        {
            echo $braces . " {\n";
            echo '  "id": "' .$result['id']. '",' . "\n";
            echo '	"text": "' . $result['id'] .'"' . "\n";
            $braces = ",\n";
            echo "}\n";
        }
        echo "]";
    }
    public function search_result_by_ward($qs)
    {
        if(!empty($qs)) {
            $query = $this->db->select('*')
                ->where('patward_Id', $qs)
                ->get('admissiontbl');
            return $query->result_array();
        }
    }
    public function search_result_by_gender($qs)
    {
        if(!empty($qs)) {
            $query = $this->db->select('*')
                ->where('patSex', $qs)
                ->get('admissiontbl');
            return $query->result_array();
        }
    }
    public function search_result_by_date($qs)
    {
        if(!empty($qs)) {
            $query = $this->db->select('*')
                ->where('patAdmDate', $qs)
                ->get('admissiontbl');
            return $query->result_array();
        }
    }
    public function search_result_by_cnic_chart($qs)
    {
        if(!empty($qs)) {
            $query = $this->db->select('*')
                ->like('regNo', $qs)
                ->or_like('patName', $qs)
                ->or_like('patCNIC', $qs)
                ->get('admissiontbl');
            return $query->result_array();
        }
    }
    public function search_patient_chart($qs){
        if(!empty($qs)) {
            $query = $this->db->select('*')
                ->where('chartpatregNo', $qs)
                ->get('charttbl');
            return $query->result_array();
        }
    }
    public function insert_history($data)
    {
        return $this->db->insert('charttbl', $data);
    }
    public function insert_shift_data($data)
    {
        return $this->db->insert('shifttbl', $data);
    }
    public function insert_inverstigation($data)
    {
        return $this->db->insert('charttbl', $data);
    }
    public function insert_treatment($data)
    {
        return $this->db->insert('charttbl', $data);
    }


}

?>