<?php

class model_menu extends CI_Model {

    function __construct()
    {
        parent::__construct();
        $this->load->database('hmsdb');
    }
    function index(){

            $this->db->select("*");
            $this->db->from("menu_parent");
            $q = $this->db->get();

            $final = array();
            if ($q->num_rows() > 0) {
                foreach ($q->result() as $row) {

                    $this->db->select("*");
                    $this->db->from("menu_child");
                    $this->db->where("fk_parent_menu_id", $row->menu_id);
                    $q = $this->db->get();
                    if ($q->num_rows() > 0) {
                        $row->children = $q->result();
                    }
                    array_push($final, $row);
                }
            }
            return $final;
    }
}

?>