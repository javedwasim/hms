<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class dashboard extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

    function __construct(){
      parent::__construct();

      $this->load->model('model_hms');
}
    public function index()
	{
		$this->load->view('dashboard');

	}
	public function new_admission(){
        $data['reg_num'] = $this->model_hms->get_regNo();
	    $this->load->view('new_admission', $data);
    }
    public function shift_patient(){
        if(!empty($this->input->get("search_by_cnic"))) {
            $data['patient_list'] = $this->model_hms->search_result_by_cnic_chart($this->input->get("search_by_cnic"));
            $this->load->view('shift_patient', $data);
        }
        if(empty($this->input->get())) {
            $this->load->view('shift_patient');
        }
    }
    public function insert_user_db(){
        $udata['patName']           = $this->input->post('patName');
        $udata['patNoKType']        = $this->input->post('patNoKType');
        $udata['patNoK']            = $this->input->post('patNoKName');
        $udata['patDoB']            = $this->input->post('patDoB');
        $udata['patAge']            = $this->input->post('patAge');
        $udata['patBldGrp']         = $this->input->post('patBldGrp');
        $udata['patDisease_id']     = $this->input->post('patDisease');
        $udata['patSex']            = $this->input->post('sex');
        $udata['patCNIC']           = $this->input->post('patCnic');
        $udata['patAddress']        = $this->input->post('patAddress');
        $udata['patOccupation']     = $this->input->post('patOccupation');
        $udata['patPhone']          = $this->input->post('patPhone');
        $udata['patEntitled']       = $this->input->post('entitled');
        $udata['patunit_Id']        = $this->input->post('admitted-through');
        $udata['patShiftedFrom']    = $this->input->post('patShiftedFrom');
        $udata['patward_id']        = $this->input->post('wardName');
        $udata['patbed_id']         = $this->input->post('bedNumber');
        $udata['patAdmDate']        = $this->input->post('admDateTime');
        $udata['patChart_id']       = "22";
        $udata['patStatus']         = "Under Treatment";


        $res = $this->model_hms->insert_users_to_db($udata);

        if($res){
            $base_url = load_class('Config')->config['base_url'];
            header('location:'.$base_url."index.php/dashboard/new_admission?success=true");

        }
    }
    public function insert_discharge_db(){
        $udata['regNo']             = $this->input->post('regNo');
        $udata['patName']           = $this->input->post('patName');
        $udata['patNoKType']        = $this->input->post('patNoKType');
        $udata['patNoK']            = $this->input->post('patNoK');
        $udata['patDoB']            = $this->input->post('patDoB');
        $udata['patAge']            = $this->input->post('patAge');
        $udata['patBldGrp']         = $this->input->post('patBldGrp');
        $udata['patDisease_id']     = $this->input->post('patDisease_id');
        $udata['patSex']            = $this->input->post('patSex');
        $udata['patCNIC']           = $this->input->post('patCNIC');
        $udata['patAddress']        = $this->input->post('patAddress');
        $udata['patOccupation']     = $this->input->post('patOccupation');
        $udata['patPhone']          = $this->input->post('patPhone');
        $udata['patEntitled']       = $this->input->post('patEntitled');
        $udata['patunit_Id']        = $this->input->post('patunit_Id');
        $udata['patShiftedFrom']    = $this->input->post('patShiftedFrom');
        $udata['patward_id']        = $this->input->post('patward_id');
        $udata['patbed_id']         = $this->input->post('patbed_id');
        $udata['patAdmDate']        = $this->input->post('patAdmDate');
        $udata['patChart_id']       = $this->input->post('patChart_id');
        $udata['patStatus']         = $this->input->post('patStatus');
        $udata['discharge_advice']   = $this->input->post('discharge_advice');

        $res = $this->model_hms->insert_discharge_to_db($udata);
        $del = $this->model_hms->delete_from_adm($this->input->post('regNo'));
        $shift = $this->shift_module();
        if($res && $del){
            echo "success";
        }
    }
    public function search(){
        if(!empty($this->input->get("search_by_cnic"))) {
            $this->model_hms->ajax_search_by_cnic($this->input->get("search_by_cnic"));
        }
       if(!empty($this->input->get("search_by_ward"))) {
            $this->model_hms->ajax_search_by_ward($this->input->get("search_by_ward"));
        }
        if(!empty($this->input->get("search_discharged_by_cnic"))) {
            $this->model_hms->ajax_search_discharged_by_cnic($this->input->get("search_discharged_by_cnic"));
        }
   }
//    public function show_view_with_menu($view_name, $data) {
//        $this->load->model('model_menu');
//        $menus = $this->model_menu->index();
//        $menuitem = array('menus' => $menus);
//       // $this->load->view('menu', $menu_data);
//        $this->load->view($view_name, $data, $menuitem);
//    }
    public function view_patients(){
       if(!empty($this->input->get("search_by_cnic"))) {
           $data['patient_list'] = $this->model_hms->search_result_by_cnic($this->input->get("search_by_cnic"));
           $this->load->view('view_patients', $data);
       }
        if(!empty($this->input->get("search_by_ward"))) {
            $data['patient_list'] = $this->model_hms->search_result_by_ward($this->input->get("search_by_ward"));
            $this->load->view('view_patients', $data);
        }
        if(!empty($this->input->get("search_by_gender"))) {
            $data['patient_list'] = $this->model_hms->search_result_by_gender($this->input->get("search_by_gender"));
            $this->load->view('view_patients', $data);
        }
        if(!empty($this->input->post("search_by_date"))) {
            $data['patient_list'] = $this->model_hms->search_result_by_date($this->input->post("search_by_date"));
            $this->load->view('view_patients', $data);
        }
        if(empty($this->input->get())) {
            $this->load->view('view_patients');
        }
    }
    public function get_menus() {
        $this->load->model('model_menu');
        $menus = $this->model_menu->index();
        $data = array('menus' => $menus);
        $this->load->view('menu', $data);
    }

    public function discharge_patients(){
        if(!empty($this->input->get("search_by_cnic"))) {
            $data['patient_list'] = $this->model_hms->search_result_by_cnic($this->input->get("search_by_cnic"));
            $this->load->view('discharge_patients', $data);
        }
        elseif(!empty($this->input->get("search_discharged_by_cnic"))) {
            $data['patient_list'] = $this->model_hms->search_result_discharged_by_cnic($this->input->get("search_discharged_by_cnic"));
            $this->load->view('discharge_patients', $data);
        }
        else {
            $this->load->view('discharge_patients');
        }
    }
    public function patient_chart(){
        if(!empty($this->input->get("search_by_cnic"))) {
            $data['patient_list'] = $this->model_hms->search_result_by_cnic_chart($this->input->get("search_by_cnic"));
            $data['patient_chart'] = $this->model_hms->search_patient_chart($this->input->get("search_by_cnic"));
            $this->load->view('patient_chart', $data);
        }
        if(empty($this->input->get()))  {
            $this->load->view('patient_chart');
        }
    }
    public function insert_brief_history(){
        $udata['patHistory']           = $this->input->post('patHistory');
        $udata['chartpatregNo']        = $this->input->post('chartpatregNo');
        $udata['docName']           = "Dr. Ahmad";
        $res = $this->model_hms->insert_history($udata);
        if($res){
          echo "success";
        }
    }
    public function insert_inv_plan()
    {
        $udata['patInvestigation'] = $this->input->post('patInvestigation');
        $udata['chartpatregNo']           = $this->input->post('chartpatregNo');
//        $udata['docName']           = $this->input->post('docName');
        $udata['docName']           = "Dr. Ahmad";
        $res = $this->model_hms->insert_inverstigation($udata);
        if($res){
            echo "success";
        }
    }
    public function insert_treatment_plan(){
        $udata['patTreatPlan'] = $this->input->post('patTreatPlan');
        $udata['chartpatregNo']           = $this->input->post('chartpatregNo');
//        $udata['docName']           = $this->input->post('docName');
        $udata['docName']           = "Dr. Ahmad";
        $res = $this->model_hms->insert_treatment($udata);
        if($res){
            echo "success";
        }
    }
    public function shift_module()
    {

        $udata['shiftFrom']           = $this->input->post('shiftFrom');
        $udata['shiftTo']             = $this->input->post('shiftTo');
        $udata['shiftPatId']          = $this->input->post('shiftPatId');
        $udata['patOutcome']          = $this->input->post('patOutcome');
        $udata['shiftBy']             = $this->input->post('shiftBy');
       if(!empty($this->input->post('shiftFrom')) || !empty($this->input->post('shiftTo')) || !empty($this->input->post('shiftPatId')) || !empty($this->input->post('patOutcome')) || !empty($this->input->post('shiftBy'))) {
           $res = $this->model_hms->insert_shift_data($udata);
           if($res){
               echo "success";
           }
       }

    }

}

