<?php foreach ($menus as $menu) { ?>
    <li <?php if(isset($menu->children)){ ?> class="treeview" <?php } ?>>
        <a href="<?php if(!empty($menu->parent_menu_link)) { echo $menu->parent_menu_link; } else {echo "#";}  ?>" <?php if(!empty($menu->menu_collapser_id)) { echo 'id="'.$menu->menu_collapser_id.'"'; } ?>>
            <i class="<?php echo $menu->menu_icon; ?>"></i>
            <span><?php echo $menu->menu_name; ?></span>
            <span class="pull-right-container">
                <?php if(isset($menu->children)){ ?>
              <i class="fa fa-plus-circle pull-right"></i>
                <?php } ?>
            </span>
        </a>
        <ul class="treeview-menu">
        <?php if(isset($menu->children)) { foreach ($menu->children as $child) { ?>
            <li>
                <a class="ahref" href="<?php echo $child->child_menu_url; ?>">
                    <i class="fa fa-circle-o"></i>
                    <?php echo $child->child_menu_name; ?>
                </a>
            </li>
        <?php } } ?>
        </ul>
    </li>

<?php } ?>


